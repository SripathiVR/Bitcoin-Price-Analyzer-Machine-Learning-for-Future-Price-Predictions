import streamlit as st
import pandas as pd
import joblib

# Load the trained model
model = joblib.load(r'D:\Guvi\Own_Projects\Bitcoin_Price_Prediction\Bitcoin_price_model.joblib')

# Get the correct feature order from the model
feature_order = model.feature_names_in_

# App title and layout
st.set_page_config(page_title="Bitcoin Price Prediction", layout="wide")
st.title("Bitcoin Price Prediction App")
st.markdown("Predict the future price of Bitcoin using machine learning.")

# Sidebar inputs for user data
st.sidebar.header('User Input Parameters')

def user_input_features():
    adj_close = st.sidebar.number_input('Adjusted Close (Adj Close)', min_value=0.0, max_value=50000.0, value=20000.0)
    high = st.sidebar.number_input('High', min_value=0.0, max_value=50000.0, value=25000.0)
    low = st.sidebar.number_input('Low', min_value=0.0, max_value=50000.0, value=15000.0)
    open_val = st.sidebar.number_input('Open', min_value=0.0, max_value=50000.0, value=20000.0)
    volume = st.sidebar.number_input('Volume', min_value=0.0, max_value=10000000.0, value=3000000.0)
    ma_7 = st.sidebar.number_input('7-Day Moving Average (MA_7)', min_value=0.0, max_value=50000.0, value=20000.0)
    ma_30 = st.sidebar.number_input('30-Day Moving Average (MA_30)', min_value=0.0, max_value=50000.0, value=25000.0)
    
    data = {
        'Adj Close': adj_close,
        'High': high,
        'Low': low,
        'Open': open_val,
        'Volume': volume,
        'MA_7': ma_7,
        'MA_30': ma_30
    }
    
    features = pd.DataFrame(data, index=[0])
    
    # Reorder columns to match the model's training order
    features = features[feature_order]
    
    return features

input_df = user_input_features()

# Main panel
st.subheader('User Input Parameters')
st.write(input_df)

# Prediction button
if st.button('Predict'):
    # Prediction
    prediction = model.predict(input_df)
    st.subheader('Prediction')
    st.write(f"Predicted Bitcoin Closing Price: ${prediction[0]:.2f}")

# Add some custom CSS styling
st.markdown(
    """
    <style>
    .sidebar .sidebar-content {
        background-image: linear-gradient(#2e7bcf,#2e7bcf);
        color: white;
    }
    .reportview-container .main .block-container{
        padding-top: 2rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown("<hr>", unsafe_allow_html=True)
st.markdown("Created by [Sripathi V R]")


